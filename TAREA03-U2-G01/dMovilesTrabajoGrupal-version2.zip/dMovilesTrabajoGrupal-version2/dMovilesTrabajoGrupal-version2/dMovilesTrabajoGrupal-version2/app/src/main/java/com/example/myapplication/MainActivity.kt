package com.example.myapplication

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import java.security.MessageDigest

@Suppress("DEPRECATION")
class MainActivity : AppCompatActivity() {

    data class Usuario(val nombreUsuario: String, val contrasenia: String)
    val usuarios = mutableListOf(
        Usuario("usuario1", "d48b165d1e5a63b56c7601e4269642e6a71fa90b2178a0212a1da5f7ee54255f"),
        Usuario("usuario2", "contrasena2"),
        Usuario("usuario3", "contrasena3")
    )

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        configurarPantallaPrincipal()
    }

    private fun configurarPantallaPrincipal() {
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val usuarioInput = findViewById<EditText>(R.id.usuario_input)
        val contraseniaInput = findViewById<EditText>(R.id.contrasenia_input)
        val botonLogin = findViewById<Button>(R.id.login_btn)
        val registrarse = findViewById<TextView>(R.id.registrarse)

        botonLogin.setOnClickListener {
            val usuario = usuarioInput.text.toString()
            val contrase = contraseniaInput.text.toString()
            val contraseHash = hashString(contrase)

            Log.i("Login", "Contraseña en hash= $contraseHash")
            val usuarioValido = usuarios.find { it.nombreUsuario == usuario && it.contrasenia == contraseHash }

            if (usuarioValido != null) {
                Log.i("Login", "Login exitoso: Usuario: $usuario")
                val intent = Intent(this, SecondActivity::class.java)
                startActivity(intent)
                finish()
            } else {
                Log.i("Login", "Login fallido: Usuario o contraseña incorrectos")
                Toast.makeText(this, "Usuario o contraseña incorrectos", Toast.LENGTH_SHORT).show()
            }
        }

        registrarse.setOnClickListener {
            configurarPantallaRegistro()
        }
    }

    private fun configurarPantallaRegistro() {
        setContentView(R.layout.activity_registrarse)

        val botonRegistrarse = findViewById<Button>(R.id.registro_btn)
        val usuarioRegistro = findViewById<EditText>(R.id.usuario_registro)
        val contraseniaRegistro = findViewById<EditText>(R.id.contrasenia_registro)

        botonRegistrarse.setOnClickListener {
            val usuario = usuarioRegistro.text.toString()
            val contrase = contraseniaRegistro.text.toString()
            val contraseHash = hashString(contrase)

            Log.i("Registro", "Contraseña en hash= $contraseHash")
            val usuarioExistente = usuarios.find { it.nombreUsuario == usuario }
            if (usuarioExistente != null) {
                Log.i("Registro", "Usuario ya existe")
                Toast.makeText(this, "Usuario ya existe", Toast.LENGTH_SHORT).show()
            } else {
                Log.i("Registro", "Usuario registrado: Usuario: $usuario")
                usuarios.add(Usuario(usuario, contraseHash))
                Toast.makeText(this, "Usuario registrado", Toast.LENGTH_SHORT).show()

                // Regresa a la pantalla principal
                setContentView(R.layout.activity_main)
                configurarPantallaPrincipal()
            }
        }
    }

    private fun hashString(input: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(input.toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }


}
