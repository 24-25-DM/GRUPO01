package com.example.myapplication

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat

class SecondActivity : AppCompatActivity() {

    private lateinit var vehiculoAdapter: VehiculoAdapter
    private val vehiculos = mutableListOf<Vehiculo>() // Lista mutable para los vehículos

    companion object {
        const val REQUEST_AGREGAR_VEHICULO = 1
        const val REQUEST_EDITAR_VEHICULO = 2
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dos)

        // Agregar vehículos por defecto
        vehiculos.addAll(listaVehiculosPredeterminados())

        //text cerrar sesion
        val cerrarSesion = findViewById<TextView>(R.id.cerrarSesionid)
        cerrarSesion.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
            finish()
        }

        // Configurar el adaptador para la lista
        vehiculoAdapter = VehiculoAdapter(
            this, vehiculos,
            onEdit = { vehiculo, position -> editVehiculo(vehiculo, position) },
            onDelete = { position -> deleteVehiculo(position) }
        )

        val listView = findViewById<ListView>(R.id.listView)
        listView.adapter = vehiculoAdapter

        // Configurar clic para editar
        listView.setOnItemClickListener { _, _, position, _ ->
            val vehiculoSeleccionado = vehiculos[position]
            editVehiculo(
                vehiculoSeleccionado,
                REQUEST_EDITAR_VEHICULO
            )
        }

        // Configurar el botón para abrir el formulario
        val btnAgregarVehiculo = findViewById<Button>(R.id.btnAgregarVehiculo)
        btnAgregarVehiculo.setOnClickListener {
            val intent = Intent(this, FormularioVehiculoActivity::class.java)
            intent.putExtra("modo", "agregar")
            startActivityForResult(intent, REQUEST_AGREGAR_VEHICULO)
        }
    }

    private fun editVehiculo(vehiculo: Vehiculo, position: Int) {
        val intent = Intent(this, FormularioVehiculoActivity::class.java)
        intent.putExtra("isEditMode", true) // Indica que es modo edición
        intent.putExtra("vehiculo", vehiculo)
        intent.putExtra("position", position)
        startActivityForResult(intent, REQUEST_EDITAR_VEHICULO)
    }

    private fun deleteVehiculo(position: Int) {
        // Eliminar vehículo de la lista
        vehiculos.removeAt(position)
        vehiculoAdapter.notifyDataSetChanged() // Actualizar el adaptador
    }

    private fun listaVehiculosPredeterminados(): List<Vehiculo> {
        return listOf(
            Vehiculo(
                id = "1",
                "ABC-1234",
                "Toyota",
                SimpleDateFormat("dd/MM/yyyy").parse("01/01/2020")!!,
                "Blanco",
                20000.0,
                true,
                R.drawable.ic_vehicle
            ),
            Vehiculo(
                id = "2",
                "XYZ-7898",
                "Honda",
                SimpleDateFormat("dd/MM/yyyy").parse("15/08/2018")!!,
                "Negro",
                15000.0,
                false,
                R.drawable.ic_vehicle
            ),
            Vehiculo(
                id = "3",
                "LMN-4567",
                "Ford",
                SimpleDateFormat("dd/MM/yyyy").parse("10/12/2021")!!,
                "Azul",
                18000.0,
                true,
                R.drawable.ic_vehicle
            )
        )
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == Activity.RESULT_OK) {
            when (requestCode) {
                REQUEST_AGREGAR_VEHICULO -> { // Nuevo vehículo
                    val nuevoVehiculo = data?.getSerializableExtra("vehiculo") as? Vehiculo
                    nuevoVehiculo?.let {
                        vehiculos.add(it)
                        vehiculoAdapter.notifyDataSetChanged()
                    }
                }

                REQUEST_EDITAR_VEHICULO -> {
                    val vehiculoEditado = data?.getSerializableExtra("vehiculo") as? Vehiculo
                    val position = data?.getIntExtra("position", -1) ?: -1
                    if (vehiculoEditado != null && position >= 0) {
                        vehiculos[position] = vehiculoEditado
                        vehiculoAdapter.notifyDataSetChanged()
                    }
                }
            }
        } else if (resultCode == RESULT_FIRST_USER) { // Eliminar vehículo
            val position = data?.getIntExtra("position", -1) ?: -1
            if (position >= 0 && position < vehiculos.size) {
                vehiculos.removeAt(position)
                vehiculoAdapter.notifyDataSetChanged()
            }
        }
    }
}