document.addEventListener('deviceready', onDeviceReady, false);

// Arreglo predefinido de usuarios
const users = [
    { username: "admin", password: "1234" },
    { username: "user1", password: "abcd" },
    { username: "user2", password: "5678" }
];

function onDeviceReady() {
   login();
}

function login() {
    // Obtener valores de los campos
    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;
    const errorMessage = document.getElementById("errorMessage");

    console.log("Usuario ingresado:", username);
    console.log("Contraseña ingresada:", password);

    // Buscar si el usuario existe y la contraseña coincide
    const user = users.find(user => user.username === username && user.password === password);

    if (user) {
        // Credenciales correctas
        errorMessage.style.display = "none"; // Ocultar mensaje de error
        alert(`¡Bienvenido, ${user.username}!`);

        console.log("Intentando redirigir a productos.html");
        window.location.href = 'productos.html'
    } else {
        // Credenciales incorrectas
        errorMessage.textContent = "Usuario o contraseña incorrectos.";
        errorMessage.style.display = "block"; // Mostrar mensaje de error
    }
}
