package com.example.myapplication

import android.app.Activity
import android.app.DatePickerDialog
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.myapplication.MainActivity.Usuario
import java.text.ParseException
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class FormularioVehiculoActivity : AppCompatActivity() {

    private var modoEdicion = false
    private var vehiculoOriginal: Vehiculo? = null
    private var position: Int = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_formulario_vehiculo)

        val etPlaca = findViewById<EditText>(R.id.etPlaca)
        val etMarca = findViewById<EditText>(R.id.etMarca)
        val etFechaFabricacion = findViewById<TextView>(R.id.etFechaFabricacion)
        val etColor = findViewById<Spinner>(R.id.spinnerColor)
        val etCosto = findViewById<EditText>(R.id.etCosto)
        val etActivo = findViewById<Switch>(R.id.cbActivo)
        val btnShowDatePicker = findViewById<Button>(R.id.btnShowDatePicker)
        val btnGuardar = findViewById<Button>(R.id.btnGuardarVehiculo)
        val btnEliminar = findViewById<Button>(R.id.btnEliminarVehiculo)

        val colores = arrayOf("blanco", "negro", "azul")
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, colores)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        etColor.adapter = adapter

        // Leer los extras del intent
        modoEdicion = intent.getBooleanExtra("isEditMode", false)
        position = intent.getIntExtra("position", -1)
        vehiculoOriginal = intent.getSerializableExtra("vehiculo") as? Vehiculo

        // Configuración inicial en modo edición
        if (modoEdicion) {
            vehiculoOriginal?.let {
                etPlaca.setText(it.placa)
                etMarca.setText(it.marca)
                etFechaFabricacion.text =
                    SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(it.fechaFabricacion)
                etColor.setSelection(adapter.getPosition(it.color))
                etCosto.setText(it.costo.toString())
                etActivo.isChecked = it.activo
                btnEliminar.visibility = View.VISIBLE // Mostrar botón eliminar
            } ?: run {
                // Si no hay vehículo, el modo edición no es válido
                Toast.makeText(this, "Error al cargar los datos del vehículo.", Toast.LENGTH_SHORT)
                    .show()
                finish()
            }
        } else {
            btnEliminar.visibility = View.GONE // Ocultar botón eliminar
        }

        btnGuardar.setOnClickListener {
            val placa = etPlaca.text.toString()
            if (!placa.matches(Regex("^[A-Z]{3}-\\d{4}$"))) {
                Toast.makeText(
                    this,
                    "La placa debe tener el formato \"XXX-NNNN\" donde X es letra y N es número",
                    Toast.LENGTH_SHORT
                ).show()
                return@setOnClickListener
            }
            // No incluir 0 si O
            if (!placa.contains("O")) {
                if (!placa.contains("0")) {

                    Toast.makeText(
                        this,
                        "Si la placa contiene la letra O no se puede incluir el número cero (0)",
                        Toast.LENGTH_SHORT
                    ).show()
                    return@setOnClickListener
                }
            }
            // No iniciar con las letras DFQÑ
            if(!placa.startsWith("D") or !placa.startsWith("F") or !placa.startsWith("Q") or !placa.startsWith("Ñ")) {
                Toast.makeText(
                    this,
                    "No se puede iniciar con las letras D, F, Q , Ñ ",
                    Toast.LENGTH_SHORT
                ).show()
                return@setOnClickListener
            }


            //No tener ni letras ni números consecutivos
            val enteros = listOf(0, 1, 2, 3, 4, 5, 6, 7, 8, 9)
            val abc = listOf("a", "b", "c", "d")

            val costo = etCosto.text.toString().toDoubleOrNull()
            if (costo == null || costo <= 0) {
                Toast.makeText(this, "El costo debe ser un número positivo", Toast.LENGTH_SHORT)
                    .show()
                return@setOnClickListener
            }

            val fechaFabricacionTexto = etFechaFabricacion.text.toString()
            try {
                val fechaFabricacionDate =
                    SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).parse(fechaFabricacionTexto)
                val vehiculoGuardado = if (modoEdicion) {
                    vehiculoOriginal?.copy(
                        placa = placa,
                        marca = etMarca.text.toString(),
                        fechaFabricacion = fechaFabricacionDate,
                        color = etColor.selectedItem.toString(),
                        costo = costo,
                        activo = etActivo.isChecked
                    )
                } else {
                    Vehiculo(
                        placa = placa,
                        marca = etMarca.text.toString(),
                        fechaFabricacion = fechaFabricacionDate,
                        color = etColor.selectedItem.toString(),
                        costo = costo,
                        activo = etActivo.isChecked
                    )
                }

                val resultIntent = Intent().apply {
                    putExtra("vehiculo", vehiculoGuardado)
                    putExtra("position", intent.getIntExtra("position", -1))
                }
                setResult(Activity.RESULT_OK, resultIntent)
                finish()
            } catch (e: ParseException) {
                Toast.makeText(
                    this,
                    "Fecha inválida. Usa el formato dd/MM/yyyy.",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }

        btnEliminar.setOnClickListener {
            val position = intent.getIntExtra("position", -1)
            val resultIntent = Intent().apply {
                putExtra("position", position)
            }
            setResult(Activity.RESULT_FIRST_USER, resultIntent)
            finish()
        }

        btnShowDatePicker.setOnClickListener {
            val calendario = Calendar.getInstance()
            val datePickerDialog = DatePickerDialog(
                this,
                { _, year, month, dayOfMonth ->
                    if (year < 2000) {
                        Toast.makeText(this, "El año debe ser 2000 o posterior", Toast.LENGTH_SHORT)
                            .show()
                    } else {
                        val fechaSeleccionada = String.format(
                            Locale.getDefault(),
                            "%02d/%02d/%04d",
                            dayOfMonth,
                            month + 1,
                            year
                        )
                        etFechaFabricacion.text = fechaSeleccionada
                    }
                },
                calendario.get(Calendar.YEAR),
                calendario.get(Calendar.MONTH),
                calendario.get(Calendar.DAY_OF_MONTH)
            )
            datePickerDialog.datePicker.minDate =
                Calendar.getInstance().apply { set(2000, 0, 1) }.timeInMillis
            datePickerDialog.show()
        }
    }
}